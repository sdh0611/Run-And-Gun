﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

[RequireComponent(typeof(Text))]
public class LivesCounterUI : MonoBehaviour {

    private Text livesText;

    [SerializeField]
	void Awake () {
        livesText = GetComponent<Text>();
	}
	
	
	void Update ()
    {
        livesText.text = "X " + GameMaster.RemainingLives.ToString();	
	}
}
