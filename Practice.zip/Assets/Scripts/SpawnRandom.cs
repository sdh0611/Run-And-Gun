﻿using UnityEngine;
using System.Collections;

public class SpawnRandom : MonoBehaviour {
   
    Vector3[] positions = new Vector3[5];
    public GameObject Enemyprefab = null;
    public bool isSpawn = false;
    public float spawnDelay = 1.5f;
    float spawnTimer = 0f;

    void SpawnEnemy()
    {
        if (isSpawn == true)
        {
            if(spawnTimer > spawnDelay)
            {
                int rand = Random.Range(0, positions.Length);
                Instantiate(Enemyprefab, positions[rand], Quaternion.identity);
                spawnTimer = 0f;
            }
            spawnTimer += Time.deltaTime;
        }
    }

    void CreatePositions()
    {
        float viewPosY = 1.2f;
        float viewPosX = 0f;
        float gapX = 1f / 6f;
        
        for(int i =0; i < positions.Length; i++)
        {
            viewPosX = gapX + gapX * i;
            Vector3 viewPos = new Vector3(viewPosX, viewPosY, 0);
            Vector3 worldPos = Camera.main.ViewportToWorldPoint(viewPos);
            worldPos.z = 0f;
            positions[i] = worldPos;
            print(worldPos);
        }
    }

	// Use this for initialization
	void Start () {
        CreatePositions();
	}
	
	// Update is called once per frame
	void Update () {
        SpawnEnemy();
	}
}
